function calculate(expression) {
    try {
        return Function('"use strict";return (' + expression + ')')();
    } catch (error) {
        return 'Error';
    }
}

let string = "";
let buttons = document.querySelectorAll('.button');
Array.from(buttons).forEach((button) => {
    button.addEventListener('click', (e) => {
        if (e.target.innerHTML == '=') {
            string = calculate(string);
            document.querySelector('input').value = string;
        } else if (e.target.innerHTML == '%') {
            string = calculate(string + '/100');
            document.querySelector('input').value = string;
        } else if (e.target.innerHTML == 'C') {
            string = "";
            document.querySelector('input').value = string;
        } else if (e.target.innerHTML == 'DEL') {
            string = string.substring(0, string.length - 1);
            document.querySelector('input').value = string;
        } else {
            string = string + e.target.innerHTML;
            document.querySelector('input').value = string;
        }
    });
});
